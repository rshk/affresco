/**
* Affresco.js v0.1 by Samuele Santi
* Copyright 2013 Samuele Santi
*
* Original work:
* Bootstrap.js v2.3.1 by @fat & @mdo
* Copyright 2012 Twitter, Inc.
*
* License: http://www.apache.org/licenses/LICENSE-2.0.txt
*/
